"use client";

// import React from "react";
import React, { useEffect, useState } from "react";

import { observer } from "mobx-react-lite";
import selectionPageStore from "../../../stores/SelectionPageStore";

import SelectionPage from "./components/selectionPage";
import VotePage from "./components/votePage";
import { useParams } from "next/navigation"; // Import useParams from next/navigation

const GamePage = observer(() => {
  const { status } = selectionPageStore;
  const { gameId } = useParams();

  useEffect(() => {
    if (gameId) {
      console.log("In useEffect", gameId);
      selectionPageStore.joinSession(gameId);

      return () => {
        selectionPageStore.cleanup();
      };
    }
  }, [gameId]);

  if (status == "started") {
    return <VotePage />;
  }

  return <SelectionPage />;
});

export default GamePage;
