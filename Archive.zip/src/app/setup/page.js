"use client";

import React, { useState } from "react";
import { observer } from "mobx-react-lite";
import selectionPageStore from "../../stores/SelectionPageStore";
import { Button, TextField } from "@mui/material";
import { useRouter } from "next/navigation"; // Import useRouter hook

const SelectionPage = observer(() => {
  const router = useRouter();

  const [textFieldValue, setTextFieldValue] = useState("");

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        width: "100%",
        height: "100%",
      }}
    >
      <h1 style={{ margin: 10 }}>Create Custom Game ID or Use Random</h1>
      <p style={{ fontSize: 20, margin: 10 }}>
        Create a Game ID for your session so you can invite your friends to this
        session
      </p>
      <TextField
        label="Game ID"
        variant="outlined"
        value={textFieldValue}
        onChange={(e) => setTextFieldValue(e.target.value)}
        style={{ margin: 10, backgroundColor: "white" }}
      />
      <Button
        variant="contained"
        onClick={() => {
          if (textFieldValue) {
            selectionPageStore.setGameId(textFieldValue);
          }

          selectionPageStore.startSelection();
          router.push(`/game/${textFieldValue}`);
        }}
        style={{ margin: "0px 5px", margin: 10 }}
        sx={{
          height: "40px",
          width: "150px",
        }}
        disabled={!textFieldValue}
      >
        Setup Session
      </Button>
    </div>
  );
});

export default SelectionPage;
