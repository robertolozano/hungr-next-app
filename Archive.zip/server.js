const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const next = require("next");

const dev = process.env.NODE_ENV !== "production";
const app = next({ dev });
const handle = app.getRequestHandler();

app.prepare().then(() => {
  const server = express();
  const httpServer = http.createServer(server);
  const io = new Server(httpServer, {
    pingTimeout: 20000,
    pingInterval: 10000,
    cors: {
      origin: "http://localhost:3006", // Allow connections from the Next.js app
      // origin: "*", // Set this to your client URL in production for security
      methods: ["GET", "POST"],
    },
    credentials: true,
    handlePreflightRequest: (req, res) => {
      res.setHeader("Access-Control-Allow-Origin", "http://localhost:3006"); // Update for your frontend URL
      res.setHeader("Access-Control-Allow-Methods", "GET,POST");
      res.setHeader(
        "Access-Control-Allow-Headers",
        "Origin, X-Requested-With, Content-Type, Accept"
      );
      res.setHeader("Access-Control-Allow-Credentials", "true");
      res.writeHead(200);
      res.end();
    },
  });

  const sessions = {}; // Keep track of users and their readiness in each session

  const logSessionUsers = (sessionId) => {
    const room = io.sockets.adapter.rooms.get(sessionId);
    const numUsers = room ? room.size : 0;
    console.log(`Session ${sessionId} has ${numUsers} user(s) connected`);

    // Emit the updated user count to clients in the session
    io.in(sessionId).emit("userCountUpdate", { numUsers });
    console.log(
      "Emitted userCountUpdate to session:",
      sessionId,
      "with count:",
      numUsers
    );
  };

  // Function to broadcast readiness status
  const broadcastReadiness = (sessionId) => {
    const session = sessions[sessionId];
    if (session) {
      const totalUsers = session.users.length;
      const readyUsers = session.users.filter((user) => user.ready).length;
      io.in(sessionId).emit("readyStatusUpdate", {
        readyUsers,
        totalUsers,
      });

      // If all users are ready, start voting
      if (readyUsers === totalUsers) {
        io.in(sessionId).emit("startVoting");
      }
    }
  };

  // Set up WebSocket event handlers
  io.on("connection", (socket) => {
    console.log("New user connected:", socket.id);

    socket.on("joinSession", (sessionId) => {
      socket.join(sessionId);
      io.to(sessionId).emit("userCountUpdate", { numUsers: 1 }); // Temporary test

      // Initialize session if not present
      if (!sessions[sessionId]) {
        sessions[sessionId] = { users: [] };
      }

      // Add the user to the session
      sessions[sessionId].users.push({ id: socket.id, ready: false });
      console.log(`User ${socket.id} joined session ${sessionId}`);
      logSessionUsers(sessionId); // Log the number of users in the session after joining

      // Broadcast the readiness status after a new user joins
      broadcastReadiness(sessionId);
    });

    socket.on("markReady", (sessionId) => {
      const session = sessions[sessionId];
      if (session) {
        const user = session.users.find((user) => user.id === socket.id);
        if (user) {
          user.ready = true;
          console.log(`User ${socket.id} is ready in session ${sessionId}`);
          broadcastReadiness(sessionId);
        }
      }
    });

    socket.on("vote", ({ sessionId, restaurantId, voteChange }) => {
      io.in(sessionId).emit("voteUpdate", { restaurantId, voteChange });
    });

    socket.on("disconnect", () => {
      console.log("User disconnected:", socket.id);

      // Remove user from the session and clean up if necessary
      Object.keys(sessions).forEach((sessionId) => {
        const session = sessions[sessionId];
        session.users = session.users.filter((user) => user.id !== socket.id);
        if (session.users.length === 0) {
          delete sessions[sessionId]; // Clean up session if no users left
        } else {
          logSessionUsers(sessionId);
          broadcastReadiness(sessionId); // Update readiness status after disconnect
        }
      });
    });
  });

  // Serve the Next.js application
  server.all("*", (req, res) => handle(req, res));

  // Start the server
  httpServer.listen(3000, (err) => {
    if (err) throw err;
    console.log("> Ready on http://localhost:3000");
  });
});
